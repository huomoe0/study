create definer = root@localhost view inventoryview as
select `factory`.`inventory`.`wid`      AS `wid`,
       `factory`.`part`.`pid`           AS `pid`,
       `factory`.`part`.`name`          AS `name`,
       `factory`.`part`.`specification` AS `specification`,
       `factory`.`inventory`.`amount`   AS `amount`
from `factory`.`inventory`
         join `factory`.`part`
where (`factory`.`inventory`.`pid` = `factory`.`part`.`pid`);

